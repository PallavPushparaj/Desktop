import {  api, LightningElement,track } from 'lwc';
import fetchAccountsList from "@salesforce/apex/accountHelper.fetchAccountsList";

export default class Input extends LightningElement {
    @track flag = false
    @api names = []
    @api accountName

    handleEdit(){
        this.flag = true
    }

    connectedCallback() {
        this.loadAccounts();
      }

      loadAccounts() {
        fetchAccountsList()
            .then((result) => {
                this.names = result.map((account) => ({
                    label: account.Name,
                    value: account.Name,
                }));
                this.accountName = this.names[0].value; // Set the value of the selected option to the first item in the names array
                console.log('Names:', this.names);
                console.log('Account name:', this.accountName);
            })
            .catch((error) => {
                console.log(error);
            });
    }

      handleAccountNames(event){
        this.accountName = event.target.value
      }      
    
}